// AgriImpact animations
