// AgriImpact dashboard interactions
