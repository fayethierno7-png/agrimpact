// AgriImpact main JavaScript
