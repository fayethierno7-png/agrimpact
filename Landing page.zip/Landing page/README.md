# AgriImpact — Landing page

Structure initiale du projet.
